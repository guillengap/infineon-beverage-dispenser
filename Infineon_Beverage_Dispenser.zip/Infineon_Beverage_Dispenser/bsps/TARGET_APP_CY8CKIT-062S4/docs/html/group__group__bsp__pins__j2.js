var group__group__bsp__pins__j2 =
[
    [ "CYBSP_J2_1", "group__group__bsp__pins__j2.html#ga2928c0efaf596b9a1a2739be34d30afa", null ],
    [ "CYBSP_J2_2", "group__group__bsp__pins__j2.html#gab60587a5479714795602b0bbfaef85a4", null ],
    [ "CYBSP_J2_3", "group__group__bsp__pins__j2.html#ga48ff7a9d2f79351cd745bf00ebe1d6ea", null ],
    [ "CYBSP_J2_4", "group__group__bsp__pins__j2.html#ga84ef9b47650cc51e597bee8359de6ae2", null ],
    [ "CYBSP_J2_5", "group__group__bsp__pins__j2.html#ga3da7a7ac8f0659e9a5cc2a397cf4aeb0", null ],
    [ "CYBSP_J2_7", "group__group__bsp__pins__j2.html#ga582997c2fc8247293d7931cbb840798a", null ],
    [ "CYBSP_J2_9", "group__group__bsp__pins__j2.html#ga37bc159883dafce4a540940658d38101", null ],
    [ "CYBSP_J2_10", "group__group__bsp__pins__j2.html#ga720c63483ba499f759c07d878894c816", null ],
    [ "CYBSP_J2_11", "group__group__bsp__pins__j2.html#gacd997157d0fe86fbea789eac342ec458", null ],
    [ "CYBSP_J2_12", "group__group__bsp__pins__j2.html#gacfd14b254b5a18710b786ec15f43759c", null ],
    [ "CYBSP_J2_13", "group__group__bsp__pins__j2.html#ga234dcb185b3018eef4e63f99fa6ae432", null ],
    [ "CYBSP_J2_15", "group__group__bsp__pins__j2.html#ga5192402f5a9902f68c95dc873a6d7737", null ],
    [ "CYBSP_J2_16", "group__group__bsp__pins__j2.html#ga6163fd86d72d8841a5f3426ab8b9a0a3", null ],
    [ "CYBSP_J2_14", "group__group__bsp__pins__j2.html#ga6b69472cf97a36f5e2a3b9adce3ca609", null ]
];