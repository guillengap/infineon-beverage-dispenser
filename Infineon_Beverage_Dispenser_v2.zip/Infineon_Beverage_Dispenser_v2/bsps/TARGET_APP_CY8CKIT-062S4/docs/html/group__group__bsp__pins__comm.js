var group__group__bsp__pins__comm =
[
    [ "CYBSP_DEBUG_UART_RX", "group__group__bsp__pins__comm.html#gae1daa9ae5985d8f4002347eee1362c76", null ],
    [ "CYBSP_DEBUG_UART_TX", "group__group__bsp__pins__comm.html#gaea8cd882c067c13b1411796d5235286d", null ],
    [ "CYBSP_I2C_SCL", "group__group__bsp__pins__comm.html#ga034bfe0f68224dd376a9a79e07ab3451", null ],
    [ "CYBSP_I2C_SDA", "group__group__bsp__pins__comm.html#gad178ee7378678fe5829a826f9a4ed0b8", null ],
    [ "CYBSP_SWDIO", "group__group__bsp__pins__comm.html#ga9fba070d4040d6aa4f3e429bdfc38946", null ],
    [ "CYBSP_SWDCK", "group__group__bsp__pins__comm.html#ga8f50aad29445466679abdcc75dcd9796", null ],
    [ "CYBSP_SPI_MOSI", "group__group__bsp__pins__comm.html#ga07b4c8b6a15a1e614ff9be2ebe8088fd", null ],
    [ "CYBSP_SPI_MISO", "group__group__bsp__pins__comm.html#gaf6282da9ac2be0fe7a4ac84735a24bb0", null ],
    [ "CYBSP_SPI_CLK", "group__group__bsp__pins__comm.html#gabeb93b3f9b953934666f83a1a97c4367", null ],
    [ "CYBSP_SPI_CS", "group__group__bsp__pins__comm.html#gad8d3655d655bb752363587ea521c8856", null ],
    [ "CYBSP_SWO", "group__group__bsp__pins__comm.html#ga83425838dc05860473aebf66214ed9d3", null ],
    [ "CYBSP_QSPI_SS", "group__group__bsp__pins__comm.html#ga020ca7a044acda4b35e451513e5830df", null ],
    [ "CYBSP_QSPI_D3", "group__group__bsp__pins__comm.html#ga2ad55ac5a5ea027d72c8f702c7f9bbde", null ],
    [ "CYBSP_QSPI_D2", "group__group__bsp__pins__comm.html#gada7037ba6e38219866f2892f87886b62", null ],
    [ "CYBSP_QSPI_D1", "group__group__bsp__pins__comm.html#ga432faefd95828b8d45709aa8302a9433", null ],
    [ "CYBSP_QSPI_D0", "group__group__bsp__pins__comm.html#gaaea1a4ddc9aa57c45c4d6695b78ee878", null ],
    [ "CYBSP_QSPI_SCK", "group__group__bsp__pins__comm.html#ga2bae07a55adc9f31e828312bc8fbdd82", null ]
];